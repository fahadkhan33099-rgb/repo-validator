"""Repo Validator: clone (or open) a repo, detect its test setup, run the tests,
and produce a JSON report. Useful for validating many repos in bulk, e.g. when
building or checking datasets for LLM evaluation."""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def detect_test_command(repo: Path):
    """Return the command used to run tests, or None if nothing is detected."""
    if (repo / "package.json").exists():
        return ["npm", "test", "--silent"]
    if (repo / "go.mod").exists():
        return ["go", "test", "./..."]
    has_py_tests = (
        (repo / "tests").is_dir()
        or any(repo.glob("test_*.py"))
        or (repo / "pytest.ini").exists()
    )
    if has_py_tests:
        return [sys.executable, "-m", "pytest", "-q"]
    return None


def run_tests(repo: Path, cmd, timeout: int = 300) -> dict:
    """Run the test command and return a result dict."""
    start = time.time()
    try:
        proc = subprocess.run(
            cmd, cwd=repo, capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "exit_code": None,
                "duration_seconds": round(time.time() - start, 2),
                "output_tail": ""}
    except FileNotFoundError as e:
        return {"status": "error", "exit_code": None,
                "duration_seconds": 0, "output_tail": str(e)}
    output = (proc.stdout + proc.stderr).strip()
    return {
        "status": "passed" if proc.returncode == 0 else "failed",
        "exit_code": proc.returncode,
        "duration_seconds": round(time.time() - start, 2),
        "output_tail": "\n".join(output.splitlines()[-15:]),
    }


def validate_repo(source: str, timeout: int = 300) -> dict:
    """Validate a local path or a git URL and return a report dict."""
    report = {"source": source, "test_command": None}
    tmp_dir = None
    try:
        path = Path(source)
        if path.is_dir():
            repo = path
        else:
            tmp_dir = tempfile.mkdtemp(prefix="repo_validator_")
            clone = subprocess.run(
                ["git", "clone", "--depth", "1", source, tmp_dir],
                capture_output=True, text=True,
            )
            if clone.returncode != 0:
                report.update(status="error", output_tail=clone.stderr.strip())
                return report
            repo = Path(tmp_dir)

        cmd = detect_test_command(repo)
        if cmd is None:
            report.update(status="no_tests_found")
            return report
        report["test_command"] = " ".join(cmd)
        report.update(run_tests(repo, cmd, timeout))
        return report
    finally:
        if tmp_dir:
            shutil.rmtree(tmp_dir, ignore_errors=True)


def main():
    parser = argparse.ArgumentParser(description="Validate repos by running their tests.")
    parser.add_argument("sources", nargs="+", help="Git URLs or local folders")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--output", default="report.json")
    args = parser.parse_args()

    results = [validate_repo(s, args.timeout) for s in args.sources]
    Path(args.output).write_text(json.dumps(results, indent=2))
    for r in results:
        print(f"{r['status'].upper():15} {r['source']}")
    print(f"\nFull report written to {args.output}")


if __name__ == "__main__":
    main()
