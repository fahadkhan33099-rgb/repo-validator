# Repo Validator

A small Python CLI that validates software repositories automatically. Give it
Git URLs or local folders and it will:

1. Clone the repo (shallow clone) or open the local folder
2. Detect the test setup (pytest, npm, or Go)
3. Run the tests with a timeout
4. Write a JSON report with status, exit code, duration, and the last lines of output

Statuses: `passed`, `failed`, `no_tests_found`, `timeout`, `error`.

## Why

Checking whether repos build and pass their tests is a core step when preparing
and validating code datasets for LLM evaluation. This tool automates that step.

## Usage

```bash
python repo_validator.py https://github.com/user/some-repo ./local-project
python repo_validator.py <repo> --timeout 120 --output my_report.json
```

Example output:

```
PASSED          ./local-project
FAILED          https://github.com/user/some-repo
```

## Run the tests

```bash
pip install -r requirements.txt
pytest
```

## Tools

Python 3, subprocess, argparse, pytest, Git

## Ideas for next steps

- Run repos in Docker for isolation
- Validate in parallel
- Add more languages (Java, Rust)
- Score LLM-generated patches by running them against a repo's tests
