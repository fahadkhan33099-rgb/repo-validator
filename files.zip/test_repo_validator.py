from repo_validator import detect_test_command, validate_repo


def make_repo(tmp_path, test_body):
    (tmp_path / "test_sample.py").write_text(test_body)
    return tmp_path


def test_detects_pytest(tmp_path):
    make_repo(tmp_path, "def test_ok():\n    assert True\n")
    assert "pytest" in " ".join(detect_test_command(tmp_path))


def test_detects_nothing_in_empty_repo(tmp_path):
    assert detect_test_command(tmp_path) is None


def test_passing_repo(tmp_path):
    make_repo(tmp_path, "def test_ok():\n    assert 1 + 1 == 2\n")
    assert validate_repo(str(tmp_path))["status"] == "passed"


def test_failing_repo(tmp_path):
    make_repo(tmp_path, "def test_bad():\n    assert 1 == 2\n")
    assert validate_repo(str(tmp_path))["status"] == "failed"


def test_repo_without_tests(tmp_path):
    (tmp_path / "readme.txt").write_text("hello")
    assert validate_repo(str(tmp_path))["status"] == "no_tests_found"
